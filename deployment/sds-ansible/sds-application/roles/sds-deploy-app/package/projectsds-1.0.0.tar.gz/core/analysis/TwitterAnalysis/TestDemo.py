# from core.analysis.TwitterAnalysis.PopularWords import getPopularWords

# info=open("Resources/decrease.txt",'r').read()

# # print(getPopularWords("Resouces/colle",150))
